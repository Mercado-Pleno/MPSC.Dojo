NPortugol
=========

NPortugol é uma linguagem de programação para elaboração de scripts com sintaxe em língua portuguesa e utilização hospedada em aplicações nas plataformas .NET e Mono. 

A linguagem utiliza como base o paradigma de programação estruturada, priorizando a simplicidade na sua codificação. A linguagem inclui recursos de interoperabilidade entre o script e a plataforma .NET permitindo a utilização indireta da API nativa C#.


Website: http://ricardoborges.github.io/NPortugol/
