using System.Collections.Generic;

namespace NPortugol.Runtime
{
    public class FunctionTable: Dictionary<string, Function>
    {
        
    }
}