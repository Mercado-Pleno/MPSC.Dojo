using System.Collections.Generic;

namespace NPortugol.Runtime
{
    public class ParamStack: Stack<IStackItem>
    {
        
    }
}