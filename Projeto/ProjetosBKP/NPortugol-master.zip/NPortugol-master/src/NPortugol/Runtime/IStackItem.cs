namespace NPortugol.Runtime
{
    public interface IStackItem
    {
        string Name { get; }
    }
}