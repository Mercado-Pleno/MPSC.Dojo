namespace NPortugol.Modulos
{
    public class ModuloCalculo
    {
        
    }
}