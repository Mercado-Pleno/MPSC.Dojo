namespace GrammarIDE.Views.Configuration
{
    public interface IConfigView
    {
        
    }
}