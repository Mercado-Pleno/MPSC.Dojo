package br.gov.saude.esus.transport.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.thrift.TBase;
import org.apache.thrift.TException;
import org.apache.thrift.TFieldIdEnum;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.transport.TIOStreamTransport;

import br.gov.saude.esus.thrift.thrift.CidadaoTransportThrift;
import br.gov.saude.esus.thrift.thrift.EnderecoTransportThrift;
import br.gov.saude.esus.thrift.thrift.SexoThrift;
import br.gov.saude.esus.thrift.thrift.TipoSanguineoThrift;

public class ExemploThriftCidadaoJava {

	public static void main(String[] args) {
		List<CidadaoTransportThrift> cidadaos = new ArrayList<CidadaoTransportThrift>();
		cidadaos.add(createCidadaoExemplo1());
		cidadaos.add(createCidadaoExemplo2());

		final File f = new File("c:\\temp\\cidadaos_exemplo.zip");
		ZipOutputStream out = null;
		try {
			out = new ZipOutputStream(new FileOutputStream(f));
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		}
		if (out != null) {
			for (CidadaoTransportThrift cidadaoTransportThrift : cidadaos) {
				byte[] data;
				try {
					String entryName = "";
					if (isNotBlank(cidadaoTransportThrift.getCns())) {
						entryName = "-" + cidadaoTransportThrift.getNumeroProntuarioCnes() + "-" + cidadaoTransportThrift.getNumeroProntuario();
					}
					entryName = cidadaoTransportThrift.getCns() + "-" + entryName + ".cidadao";
					out.putNextEntry(new ZipEntry(entryName));
					data = serialize(cidadaoTransportThrift);
					out.write(data);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (TException e) {
					e.printStackTrace();
				}
			}
			try {
				out.closeEntry();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static CidadaoTransportThrift createCidadaoExemplo1() {
		CidadaoTransportThrift cidadao = new CidadaoTransportThrift();
		cidadao.setCns("09876543210987");
		cidadao.setCpf("01234567890");
		cidadao.setDataNascimento(new Date().getTime());

		// Nome da mãe
		// caso o cidadão não possua o nome da mãe deve preencher o campo "desconhece o nome da mãe" com verdadeiro
		// caso preencher o campo "desconhece o nome da mãe" com verdadeiro o campo nome da mãe passa a ser obrigatório
		cidadao.setDesconheceNomeMae(false);
		cidadao.setNomeMae("NOME DA MAE");

		cidadao.setEmail("email@docidadao.com.br");
		// Escolaridade
		// usar tabelas de referência (Escolaridade) coluna "Código"
		// caso não existir utilizar o código "15" ou não preencher
		cidadao.setEscolaridadeId(2L);

		EnderecoTransportThrift endereco = new EnderecoTransportThrift();
		endereco.setArea("1");
		// Bairro
		// o e-SUS busca a referência do bairro pelo campo:
		// Dne -> código do bairro registrado na base de dados do correio
		// caso o código Dne do bairro seja encontrado na base do e-SUS os dados da localidade e UF são encontrados com base no Dne do bairro
		endereco.setBairroDne("000654");
		// caso não exista código Dne o e-SUS fará a busca pelo nome do bairro e pela localidade
		// caso a busca pelo nome e localidade não retorne um registro, o bairro informado será cadastrado no e-SUS
		endereco.setBairroNome("bairro nome");
		endereco.setComplemento("complemento");
		// Localidade
		// o e-SUS busca a referência da localidade/município pela ordem dos campo abaixo
		// Dne -> código da localidade registrada na base de dados do correio
		// Ibge
		// se mesmo com os três códigos o município não for encontrado o e-SUS não importará o campo
		endereco.setLocalidadeDne("00008452");
		endereco.setLocalidadeIbge("420540");
		endereco.setMicroArea("1");

		// Sem número
		// caso o enderço não possua um número deve ser preenchido o campo Sem Número com true. Se o valor for falso o campo número passa a ser obrigatório
		endereco.setSemNumero(false);
		endereco.setNumero("123");
		endereco.setPontoReferencia("ponto de referência do endereço");
		endereco.setUfSigla("SC");
		cidadao.setEndereco(endereco);

		// Estado Civil
		// usar tabelas de referência (Estao Civil) coluna "Código"
		// caso não existir não preencher
		cidadao.setEstadoCivilId(1L);

		cidadao.setEstrangeiro(false);

		// Etnia
		// usar tabelas de referência (Etnia) coluna "Código"
		// caso não existir não preencher
		cidadao.setEtniaId(65L);

		cidadao.setFaleceu(false);

		// Municípiio
		// o e-SUS busca a referência da localidade/município pela ordem dos campo abaixo
		// Dne -> código da localidade registrada na base de dados do correio
		// Ibge
		// Cep
		// se mesmo com os três códigos o município não for encontrado o e-SUS não importará o campo
		cidadao.setMunicipioNascimentoDne("00008452");
		cidadao.setMunicipioNascimentoIbge("420540");
		cidadao.setMunicipioNascimentoCep("88036003");

		// Não possui cns
		// Este campo tem a função de indicar, manualmente, que o cidadão não possui um CNS, caso marcado com falso o campo CNS se torna obrigatório
		cidadao.setNaoPossuiCns(false);

		cidadao.setNisPisPasep("1234567");
		cidadao.setNomeCompleto("ALEXANDRE MATTJE");

		// número do prontuario e numero prontuário cnes
		// Indica o número do prontuário do cidadão em uma determinada unidade de saúde
		// Para registrar um cidadão com número de prontuário em cada unidade de saúde deve se exportar uma linha com todos os dados do cidadão para cada unidade de saúde
		cidadao.setNumeroProntuario("123456");
		cidadao.setNumeroProntuarioCnes("1234567");

		// Raça Cor
		// Campo obrigatório
		// usar tabelas de referência (Etnia) coluna "Código"
		// caso não existir não preencher
		// Caso for 5-indígena o campo Etnia deve ser preenchido
		cidadao.setRacaCorId(4L);

		cidadao.setSexo(SexoThrift.MASCULINO);
		cidadao.setTelefoneCelular("4898765432");
		cidadao.setTelefoneContato("4890876543");
		cidadao.setTelefoneResidencial("4876543219");
		cidadao.setTipoSanguineo(TipoSanguineoThrift.A_NEGATIVO);
		return cidadao;
	}

	private static CidadaoTransportThrift createCidadaoExemplo2() {
		// Exemplo de cidadão com o mínimo necessário
		CidadaoTransportThrift cidadao = new CidadaoTransportThrift();
		cidadao.setDataNascimento(new Date().getTime());

		cidadao.setDesconheceNomeMae(true);

		// caso for estrangeiro for falso o campo município de nascimento passa a ser obrigatório
		// caso for verdadeiro o campo município pode ser vazio
		cidadao.setEstrangeiro(false);
		cidadao.setMunicipioNascimentoDne("00008452");
		cidadao.setMunicipioNascimentoIbge("420540");
		cidadao.setMunicipioNascimentoCep("88036003");

		cidadao.setNaoPossuiCns(false);
		cidadao.setCns("09876543210987");

		cidadao.setNomeCompleto("ALEXANDRE MATTJE");

		// Raça Cor
		// Campo obrigatório
		// usar tabelas de referência (Etnia) coluna "Código"
		// caso não existir não preencher
		// Caso for 5-indígena o campo Etnia deve ser preenchido
		cidadao.setRacaCorId(4L);

		cidadao.setSexo(SexoThrift.MASCULINO);

		return cidadao;
	}

	public static byte[] serialize(TBase<?, ? extends TFieldIdEnum> thrift) throws TException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		TIOStreamTransport transport = new TIOStreamTransport(baos);
		TBinaryProtocol protocol = new TBinaryProtocol(transport);
		thrift.write(protocol);
		return baos.toByteArray();
	}

	public static void unserialize(byte[] data, TBase<?, ? extends TFieldIdEnum> thrift) throws TException {
		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		TIOStreamTransport transport = new TIOStreamTransport(bais);
		TBinaryProtocol protocol = new TBinaryProtocol(transport);
		thrift.read(protocol);
	}

	public static Long castToLong(Object value, Long defaultValue) {
		if (value != null) {
			if (value instanceof Long) {
				return (Long) value;
			} else if (value instanceof Number) {
				return new Long(((Number) value).longValue());
			} else if (value instanceof String) {
				try {
					return value.equals("") ? defaultValue : new Long((String) value);
				} catch (NumberFormatException exn) {
					return defaultValue;
				}
			} else if (value instanceof BigInteger) {
				return ((BigInteger) value).longValue();
			} else if (value instanceof BigDecimal) {
				return ((BigDecimal) value).longValue();
			}
		}
		return defaultValue;
	}

	public static Long castToLong(Object value) {
		return castToLong(value, null);
	}

	public static boolean isBlank(String text) {
		if (text != null && text.length() > 0) {
			for (int i = 0, iSize = text.length(); i < iSize; i++) {
				if (text.charAt(i) != ' ') {
					return false;
				}
			}
		}

		return true;
	}

	public static boolean isNotBlank(String nome) {
		return !isBlank(nome);
	}

	public static Integer castToInteger(Object value, Integer defaultValue) {
		if (value != null) {
			if (value instanceof Integer) {
				return (Integer) value;
			} else if (value instanceof Number) {
				return new Integer(((Number) value).intValue());
			} else if (value instanceof BigInteger) {
				return ((BigInteger) value).intValue();
			} else if (value instanceof BigDecimal) {
				return ((BigDecimal) value).intValue();
			} else if (value instanceof String) {
				try {
					return value.equals("") ? defaultValue : new Integer((String) value);
				} catch (NumberFormatException exn) {
					return defaultValue;
				}
			}
		}
		return defaultValue;
	}

	public static Integer castToInteger(Object value) {
		return castToInteger(value, null);
	}

}
