﻿



namespace RTF
{
    public enum RTFFont
    {
                 Arial,
                ArialBlack,
                BookmanOldStyle,
                Broadway,
                CenturyGothic ,
                Consolas ,
                CordiaNew ,
                CourierNew,
                FontTimesNewRoman,
                Garamond,
                Georgia ,
                Impact ,
                LucidaConsole ,
                Symbol ,
                WingDings ,
                MSSansSerif  
    }
}


