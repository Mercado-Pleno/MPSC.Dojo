namespace MBCorpHealth.Dominio
{
    public class ServicoDePersistenciaDeMedico
    {
        public bool Gravar(Medico medico)
        {   //l�gica de grava��o
            return true;
        }
    }
}