﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Factory
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
