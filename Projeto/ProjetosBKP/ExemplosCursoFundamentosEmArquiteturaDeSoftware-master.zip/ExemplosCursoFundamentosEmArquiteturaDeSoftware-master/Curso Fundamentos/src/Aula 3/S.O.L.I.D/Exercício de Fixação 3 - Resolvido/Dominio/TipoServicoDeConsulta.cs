namespace MBCorpHealth.Dominio
{
    public enum TipoServicoDeConsulta
    {
        ServicoCorporativo,
        ServicoCorreios,
        ServicoCorporativoAtual,
        ServicoCorporativoAtualAtualizado
    }
}