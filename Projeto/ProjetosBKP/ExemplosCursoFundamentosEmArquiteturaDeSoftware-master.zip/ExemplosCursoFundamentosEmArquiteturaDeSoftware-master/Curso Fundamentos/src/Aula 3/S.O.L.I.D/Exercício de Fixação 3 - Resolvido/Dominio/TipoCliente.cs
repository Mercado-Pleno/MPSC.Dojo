namespace MBCorpHealth.Dominio.Contratos
{
    internal enum TipoCliente
    {
        VIP,
        COMUN
    }
}