﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MBCorpHealthTestTest
{
    [TestClass]
    public class TestesIntegradosContextoCadastrosCorporativos
    {
        [TestMethod]
        public void ComoAtendenteQueroConsultarUmMedicoPorCRMEEstadoIntegrado()
        {
            ////Arrange

            //using (var session = NHibernateSessionFactory.Criar().OpenSession())
            //{
            //    IMedicos medicos = new Medicos(session);


            ////Act
            //Medico medico = medicos.PesquisarMedicoPorCRMEEstado("123", "SP");

            ////Assert
            //Assert.IsTrue(medico != null);
            //Assert.IsTrue(medico.CRM == "123");
            //Assert.IsTrue(medico.Estado == "SP");

            //    }
        }
    }
}
