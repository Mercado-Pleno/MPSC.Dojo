use MBCORPHEALTHDDD 
GO

insert into tbAtendente values('222','Marcelo')
INSERT INTO TBMEDICO VALUES ('123','FABIO MARGARITO','SP')
INSERT INTO TBPLANOSAUDE VALUES('12345','PORTO','TOP')
insert into TBPACIENTE values ('1234','fabio paciente','fabiomargarito@gmail.com','12345')
insert into TBTIPOEXAME VALUES('1','1')
insert into TBLAUDO values (1,'teste')
insert into TBCREDENCIAL values (1,'fabiomargarito@gmail.com','1234')
insert into TBAGENDAMENTO values ('222', 1,'123','1234')
insert into TBEXAME values(1,1,'1',1)


	