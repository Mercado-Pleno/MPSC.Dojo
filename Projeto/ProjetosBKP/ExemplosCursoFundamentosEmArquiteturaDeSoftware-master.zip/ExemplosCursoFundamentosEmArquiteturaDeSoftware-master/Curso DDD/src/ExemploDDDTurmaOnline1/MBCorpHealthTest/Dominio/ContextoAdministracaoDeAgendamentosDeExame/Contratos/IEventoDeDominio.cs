﻿namespace MBCorpHealthTest.Dominio.ContextoAdministracaoDeAgendamentosDeExame.Contratos
{
    public interface IEventoDeDominio
    {
        //fabio margarito
    }
}
