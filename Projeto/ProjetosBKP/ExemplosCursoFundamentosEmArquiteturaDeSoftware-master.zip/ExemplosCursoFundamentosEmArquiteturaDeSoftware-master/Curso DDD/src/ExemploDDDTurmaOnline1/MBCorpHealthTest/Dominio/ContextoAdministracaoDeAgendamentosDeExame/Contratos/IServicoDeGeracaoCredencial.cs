﻿using MBCorpHealthTest.Dominio.ContextoAdministracaoDeAgendamentosDeExame.Entidades;

namespace MBCorpHealthTest.Dominio.ContextoAdministracaoDeAgendamentosDeExame.Contratos
{
    public interface IServicoDeGeracaoCredencial
    {
        Credencial Gerar(Paciente paciente);
    }
}