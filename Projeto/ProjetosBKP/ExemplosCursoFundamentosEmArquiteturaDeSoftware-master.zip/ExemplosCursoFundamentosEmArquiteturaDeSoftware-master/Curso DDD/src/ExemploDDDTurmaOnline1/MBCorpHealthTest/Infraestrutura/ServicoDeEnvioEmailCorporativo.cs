﻿using MBCorpHealthTest.Dominio.ContextoAdministracaoDeAgendamentosDeExame.Contratos;

namespace MBCorpHealthTest.Infraestrutura
{
    public class ServicoDeEnvioEmailCorporativo : IServicoDeEnvioEmail
    {
        public void Enviar(string de, string para, string asssunto, string mensagem)
        {

        }
    }
}