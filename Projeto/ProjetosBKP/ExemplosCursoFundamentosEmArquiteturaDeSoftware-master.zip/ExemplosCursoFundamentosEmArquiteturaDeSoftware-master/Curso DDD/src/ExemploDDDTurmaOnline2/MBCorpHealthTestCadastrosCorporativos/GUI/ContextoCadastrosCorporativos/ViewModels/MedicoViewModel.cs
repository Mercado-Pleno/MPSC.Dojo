﻿namespace MBCorpHealthTest.GUI.ViewModels
{
    public class MedicoViewModel
    {
        public  string CRM { get;  set; }
        public  string Nome { get;  set; }
    }
}
