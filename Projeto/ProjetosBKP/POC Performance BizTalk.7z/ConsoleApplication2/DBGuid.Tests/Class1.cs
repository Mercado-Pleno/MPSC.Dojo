﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Transactions;
using DBGuid.Domain;
using DBGuid.Domain.Map;
using IBM.Data.DB2.iSeries;
using NHibernate.Transaction;
using NUnit.Framework;

namespace DBGuid.Tests
{
    [TestFixture]
    public class DBGuidTests : TestBase
    {
        [Test]
        public void MedirTempoInsertMilRegistrosComIdentityADO()
        {
            ExecutarTestesAdo(CriarObjetosInsercaoIdentity(1000));
        }

        [Test]
        public void MedirTempoInsertMilRegistrosGuidADO()
        {
            ExecutarTestesAdo(CriarObjetosInsercaoGuid(1000));
        }

        [Test]
        public void MedirTempoInsertMilRegistrosComIdentityNhibernate()
        {
            ExecutarTestesNHibernate(CriarObjetosInsercaoIdentity(1000));
        }

        [Test]
        public void MedirTempoInsertMilRegistrosGuidNhibernate()
        {
            ExecutarTestesNHibernate(CriarObjetosInsercaoGuid(1000));
        }

        [Test]
        public void MedirTempoInsertCincoMilRegistrosComIdentityADO()
        {
            ExecutarTestesAdo(CriarObjetosInsercaoIdentity(5000));
        }

        [Test]
        public void MedirTempoInsertCincoMilRegistrosGuidADO()
        {
            ExecutarTestesAdo(CriarObjetosInsercaoGuid(5000));
        }

        [Test]
        public void MedirTempoInsertCincoMilRegistrosComIdentityNhibernate()
        {
            ExecutarTestesNHibernate(CriarObjetosInsercaoIdentity(5000));
        }

        [Test]
        public void MedirTempoInsertCincoMilRegistrosGuidNhibernate()
        {
            ExecutarTestesNHibernate(CriarObjetosInsercaoGuid(5000));
        }

        [Test]
        public void MedirTempoInsertDezMilRegistrosComIdentityADO()
        {
            ExecutarTestesAdo(CriarObjetosInsercaoIdentity(10000));
        }

        [Test]
        public void MedirTempoInsertDezMilRegistrosGuidADO()
        {
            ExecutarTestesAdo(CriarObjetosInsercaoGuid(10000));
        }

        [Test]
        public void MedirTempoInsertDezMilRegistrosComIdentityNhibernate()
        {
            ExecutarTestesNHibernate(CriarObjetosInsercaoIdentity(10000));
        }

        [Test]
        public void MedirTempoInsertDezMilRegistrosGuidNhibernate()
        {
            ExecutarTestesNHibernate(CriarObjetosInsercaoGuid(10000));
        }

        [Test]
        public void ObterTodosRegistrosGuidNhibernate()
        {
            var session = SessionFactory.OpenSession();
            var dataInicio = DateTime.Now;

            var todosGuid = session.CreateCriteria<TesteGuid>().List();

            RegistrarTempoExecucao(dataInicio);
        }

        [Test]
        public void ObterTodosRegistrosIdentityNhibernate()
        {
            var session = SessionFactory.OpenSession();
            var dataInicio = DateTime.Now;

            var todosGuid = session.CreateCriteria<TesteIdentity>().List();

            RegistrarTempoExecucao(dataInicio);
        }

        private void ExecutarTestesNHibernate<T>(IEnumerable<T> objetosInsercao) where T : IActiveRecord
        {
            var session = SessionFactory.OpenSession();
            var dataInicio = DateTime.Now;

            try
            {
                session.BeginTransaction();

                foreach (var objetoInsercao in objetosInsercao)
                    session.Save(objetoInsercao);

                session.Flush();
                session.Transaction.Commit();
            }
            catch (Exception)
            {
                session.Transaction.Rollback();
                throw;
            }
            finally
            {
                session.Close();
            }

            RegistrarTempoExecucao(dataInicio);
        }

        private void ExecutarTestesAdo<T>(IEnumerable<T> objetosInsercao) where T : IActiveRecord
        {
            var dataInicio = DateTime.Now;

            var connection = new iDB2Connection(ConfigurationManager.ConnectionStrings["DB2400"].ConnectionString);
            iDB2Transaction transaction = null;

            try
            {
                connection.Open();
                transaction = connection.BeginTransaction();

                foreach (var objetoInsercao in objetosInsercao)
                    InserirAdo(connection, transaction, objetoInsercao);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
                throw;
            }
            finally
            {
                connection.Close();
            }

            RegistrarTempoExecucao(dataInicio);
        }

        private void InserirAdo<T>(iDB2Connection connection, iDB2Transaction transaction, T activeRecord) where T : IActiveRecord
        {
            var command = new iDB2Command(activeRecord.GetInsert(), connection);
            command.Transaction = transaction;

            activeRecord.FillComand(command);

            command.ExecuteNonQuery();
        }

        private IEnumerable<TesteIdentity> CriarObjetosInsercaoIdentity(int quantidade)
        {
            return Enumerable.Range(0, quantidade)
                .Select(i => new TesteIdentity { Nome = "nome", Descricao = "descricao", Ordem = (short)i });
        }

        private IEnumerable<TesteGuid> CriarObjetosInsercaoGuid(int quantidade)
        {
            return Enumerable.Range(0, quantidade)
                .Select(i => new TesteGuid { Nome = "nome", Descricao = "descricao", Ordem = (short)i });
        }
    }
}