﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DBGuid.Domain.DTO;
using DBGuid.Domain.Map;
using DBGuid.Domain.Service;
using NHibernate;
using NHibernate.Transform;
using NUnit.Framework;

namespace DBGuid.Tests
{
    [TestFixture]
    public class BiztalkMsgTests : TestBase
    {
        private static readonly int dezMil = 10000;
        private static readonly int cemMil = 100000;
        private static readonly int quinhentosMil = 500000;
        private static readonly int humMilhao = 1000000;

        [Test]
        public void MedirTempoEnvioIndividualComCemMilRegistros()
        {
            var dataInicio = DateTime.Now;
            var contribuicoes = ObterContribuicoes(cemMil);

            EnviarContribuicoesIndividualmente(contribuicoes);
            RegistrarTempoExecucao(dataInicio);
        }

        [Test]
        public void MedirTempoEnvioIndividualComQuinhentosMilRegistros()
        {
            var dataInicio = DateTime.Now;
            var contribuicoes = ObterContribuicoes(quinhentosMil);

            EnviarContribuicoesIndividualmente(contribuicoes);
            RegistrarTempoExecucao(dataInicio);
        }

        [Test]
        public void MedirTempoEnvioIndividualComHumMilhaoDeRegistros()
        {
            var dataInicio = DateTime.Now;
            var contribuicoes = ObterContribuicoes(humMilhao);

            EnviarContribuicoesIndividualmente(contribuicoes);
            RegistrarTempoExecucao(dataInicio);
        }

        [Test]
        public void MedirTempoEnvioEmLoteComCemMilRegistros()
        {
            var dataInicio = DateTime.Now;
            var contribuicoes = ObterContribuicoes(cemMil);

            EnviarContribuicoesEmLote(contribuicoes);
            RegistrarTempoExecucao(dataInicio);
        }

        [Test]
        public void MedirTempoEnvioEmLoteComQuinhentosMilRegistros()
        {
            var dataInicio = DateTime.Now;
            var contribuicoes = ObterContribuicoes(quinhentosMil);

            EnviarContribuicoesEmLote(contribuicoes);
            RegistrarTempoExecucao(dataInicio);
        }

        [Test]
        public void MedirTempoEnvioEmLoteComHumMilhaoDeRegistros()
        {
            var dataInicio = DateTime.Now;
            var contribuicoes = ObterContribuicoes(humMilhao);

            EnviarContribuicoesEmLote(contribuicoes);
            RegistrarTempoExecucao(dataInicio);
        }

        private void EnviarContribuicoesEmLote(IEnumerable<Contribuicao> contribuicoes)
        {
            using (var client = new EnviarContribuicaoClient())
            {
                using (var scope = SessionFactory.OpenSession().BeginTransaction())
                {
                    for (var i = 0; i < contribuicoes.Count(); i += dezMil)
                        client.EnviarLote(new ReceberContribuicaoLote { Contribuicoes = contribuicoes.Skip(i).Take(dezMil).ToList() });

                    scope.Commit();
                }
            }
        }

        private void EnviarContribuicoesIndividualmente(IEnumerable<Contribuicao> contribuicoes)
        {
            using (var client = new EnviarContribuicaoClient())
            {
                using (var scope = SessionFactory.OpenSession().BeginTransaction())
                {
                    foreach (var contribuicao in contribuicoes)
                        client.Enviar(new ReceberContribuicao { Contribuicao = contribuicao });

                    scope.Commit();
                }
            }
        }

        private IEnumerable<Contribuicao> ObterContribuicoes(int quantidadeRegistros)
        {
            var session = SessionFactory.OpenSession();

            var query = session.CreateSQLQuery(@"select
                                                    cspc.contratoseguradoparcelacoberturaid as ContribuicaoId,
                                                    cspc.valorBruto as Valor,
                                                    csp.datainiciovigencia as Competencia
                                                    from contratoseguradoparcelacobertura cspc
                                                    inner join contratoseguradoparcela csp on cspc.contratoseguradoparcelaid = csp.contratoseguradoparcelaid");

            query.AddScalar("Competencia", NHibernateUtil.DateTime);
            query.AddScalar("ContribuicaoId", NHibernateUtil.Int64);
            query.AddScalar("Valor", NHibernateUtil.Decimal);

            query.SetMaxResults(quantidadeRegistros);
            query.SetResultTransformer(new AliasToBeanResultTransformer(typeof(Contribuicao)));

            return query.List<Contribuicao>();
        }
    }
}