﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DBGuid.Domain.Map;
using NHibernate;

namespace DBGuid.Tests
{
    public abstract class TestBase
    {
        protected static readonly ISessionFactory SessionFactory;

        static TestBase()
        {
            SessionFactory = SessionManager.SessionFactory;
        }

        protected void RegistrarTempoExecucao(DateTime dataInicio)
        {
            var tempoExecucao = DateTime.Now - dataInicio;
            Console.WriteLine(string.Format("tempo de execução {0}: {1}", "MedirTempoInsertMilRegistrosComIdentityADO", tempoExecucao));
        }
    }
}