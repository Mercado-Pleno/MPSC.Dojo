﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IBM.Data.DB2.iSeries;

namespace DBGuid.Domain
{
    public class TesteIdentity : IActiveRecord
    {
        public virtual int TesteId { get; set; }
        public virtual string Nome { get; set; }
        public virtual string Descricao { get; set; }
        public virtual short Ordem { get; set; }

        public virtual string GetInsert()
        {
            return "INSERT INTO TESTEIDENTITY (TESTEID, NOME, DESCRICAO, ORDEM) VALUES (default, @nome, @descricao, @ordem)";
        }

        public virtual void FillComand(iDB2Command command)
        {
            command.Parameters.Add("nome", Nome);
            command.Parameters.Add("descricao", Descricao);
            command.Parameters.Add("ordem", Ordem);
        }
    }
}