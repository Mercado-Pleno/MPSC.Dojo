﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Dialect;
using NHibernate.Driver;

namespace DBGuid.Domain.Map
{
    public class SessionManager
    {
        private static ISessionFactory _sessionFactory;

        public static ISessionFactory SessionFactory
        {
            get { return _sessionFactory ?? (_sessionFactory = BuildSessionFactory()); }
        }

        private static ISessionFactory BuildSessionFactory()
        {
            return Fluently.Configure()
                .Database(DB2Configuration.Standard
                    .ConnectionString(ConfigurationManager.ConnectionStrings["DB2400"].ConnectionString)
                    .Driver<DB2400Driver>()
                    .Dialect<DB2400Dialect>()
                    .ShowSql())
                .Mappings(m => m.FluentMappings.Add(typeof(TestIdentityMap)))
                .Mappings(m => m.FluentMappings.Add(typeof(TesteGuidMap)))
                .BuildSessionFactory();
        }
    }
}