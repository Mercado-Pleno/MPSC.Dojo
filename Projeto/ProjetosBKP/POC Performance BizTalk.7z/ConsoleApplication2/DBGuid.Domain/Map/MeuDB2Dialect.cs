﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using NHibernate.Dialect;

namespace DBGuid.Domain.Map
{
    public class MeuDB2Dialect : DB2400Dialect
    {
        public MeuDB2Dialect()
        {
            RegisterColumnType(DbType.Guid, "VARCHAR(40)");
        }
    }
}