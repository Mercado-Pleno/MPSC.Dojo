﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentNHibernate.Mapping;

namespace DBGuid.Domain.Map
{
    public class TesteGuidMap : ClassMap<TesteGuid>
    {
        public TesteGuidMap()
        {
            Table("TESTEGUID");
            Id(x => x.TesteId).CustomType<GuidType>().GeneratedBy.GuidComb();
            Map(x => x.Nome);
            Map(x => x.Descricao);
            Map(x => x.Ordem);
        }
    }
}