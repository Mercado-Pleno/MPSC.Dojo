﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentNHibernate.Mapping;

namespace DBGuid.Domain.Map
{
    public class TestIdentityMap : ClassMap<TesteIdentity>
    {
        public TestIdentityMap()
        {
            Table("TESTEIDENTITY");
            Id(x => x.TesteId).GeneratedBy.Identity();
            Map(x => x.Nome);
            Map(x => x.Descricao);
            Map(x => x.Ordem);
        }
    }
}