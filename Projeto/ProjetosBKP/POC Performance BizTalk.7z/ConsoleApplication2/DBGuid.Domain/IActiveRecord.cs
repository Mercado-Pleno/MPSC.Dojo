﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IBM.Data.DB2.iSeries;

namespace DBGuid.Domain
{
    public interface IActiveRecord
    {
        string GetInsert();
        void FillComand(iDB2Command command);
    }
}