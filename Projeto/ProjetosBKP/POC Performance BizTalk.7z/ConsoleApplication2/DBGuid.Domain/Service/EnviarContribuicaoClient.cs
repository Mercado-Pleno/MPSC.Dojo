﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using DBGuid.Domain.DTO;

namespace DBGuid.Domain.Service
{
    [ServiceContract(Namespace = "http://Mongeral.eSim.EmissaoPremio", ConfigurationName = "ESB.EmissaoPremio.EnviarContribuicao")]
    public interface IEnviarContribuicao
    {
        [OperationContractAttribute(IsOneWay = true, Action = "ReceberContribuicao")]
        void Enviar(ReceberContribuicao contribuicao);

        [OperationContractAttribute(IsOneWay = true, Action = "ReceberContribuicaoLote")]
        void EnviarLote(ReceberContribuicaoLote contribuicoes);
    }

    public class EnviarContribuicaoClient : ClientBase<IEnviarContribuicao>, IEnviarContribuicao
    {
        public void Enviar(ReceberContribuicao contribuicao)
        {
            Channel.Enviar(contribuicao);
        }

        public void EnviarLote(ReceberContribuicaoLote contribuicoes)
        {
            Channel.EnviarLote(contribuicoes);
        }
    }
}