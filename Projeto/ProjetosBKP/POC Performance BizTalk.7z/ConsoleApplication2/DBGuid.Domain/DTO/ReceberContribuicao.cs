﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace DBGuid.Domain.DTO
{
    [MessageContract(IsWrapped = false)]
    public class ReceberContribuicao
    {
        [MessageBodyMember(Namespace = "http://Mongeral.eSim.Orquestracoes.Schemas.Contribuicao", Order = 0)]
        public Contribuicao Contribuicao { get; set; }
    }

    [MessageContract(IsWrapped = false)]
    public class ReceberContribuicaoLote
    {
        [MessageBodyMember(Name="Contribuicoes", Namespace = "http://Mongeral.eSim.Orquestracoes.Schemas.Contribuicao", Order = 0)]
        public List<Contribuicao> Contribuicoes { get; set; }
    }
}