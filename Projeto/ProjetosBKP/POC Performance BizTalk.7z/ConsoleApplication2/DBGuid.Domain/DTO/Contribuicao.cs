﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DBGuid.Domain.DTO
{
    [DataContract(Name = "Contribuicao", Namespace = "http://Mongeral.eSim.Orquestracoes.Schemas.Contribuicao")]
    public class Contribuicao
    {
        [DataMember]
        public DateTime Competencia { get; set; }

        [DataMember]
        public long ContribuicaoId { get; set; }

        [DataMember]
        public decimal Valor { get; set; }
    }
}